import { mkdtemp, rm, mkdir, readdir, readFile, writeFile, copyFile, lstat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { resolve, join, relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { gzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';

const root = fileURLToPath(new URL('../', import.meta.url));
const destination = resolve(process.argv[2] || join(root, 'deploy/pterodactyl'));
const scratch = await mkdtemp(join(tmpdir(), 'modmail-egg-'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const files = ['package.json', 'package-lock.json', 'config.example.json', 'README.md', 'scripts/pterodactyl-start.js'];
async function collect(directory, extension) {
  for (const entry of await readdir(join(root, directory), { withFileTypes: true })) {
    if (entry.isSymbolicLink()) throw new Error(`Bundle source must not contain symlinks: ${directory}/${entry.name}`);
    if (entry.isDirectory()) await collect(`${directory}/${entry.name}`, extension);
    else if (entry.isFile() && entry.name.endsWith(extension)) files.push(`${directory}/${entry.name}`);
  }
}
try {
  await collect('src', '.js');
  await collect('plugins/example', '.js');
  await collect('docs', '.md');
  const manifest = { application: 'aarons-support', version: JSON.parse(await readFile(join(root, 'package.json'), 'utf8')).version, files: {} };
  for (const path of files.sort()) {
    if (!(await lstat(join(root, path))).isFile()) throw new Error(`Expected a regular bundle source file: ${path}`);
    const target = join(scratch, path);
    await mkdir(dirname(target), { recursive: true });
    await copyFile(join(root, path), target);
    manifest.files[path] = hash(await readFile(target));
  }
  await writeFile(join(scratch, 'pterodactyl-release.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  // GNU tar fixes metadata; gzip produces the same bytes for unchanged inputs.
  const tar = execFileSync('tar', ['--sort=name', '--mtime=@0', '--owner=0', '--group=0', '--numeric-owner', '--mode=u+rwX,go+rX', '-cf', '-', '-C', scratch, '.'], { maxBuffer: 10 * 1024 * 1024 });
  const bundle = gzipSync(tar, { level: 9 });
  const template = JSON.parse(await readFile(join(root, 'deploy/pterodactyl/egg-template.json'), 'utf8'));
  const installer = await readFile(join(root, 'deploy/pterodactyl/install.sh'), 'utf8');
  const base64 = bundle.toString('base64').match(/.{1,76}/g).join('\n');
  template.scripts.installation.script = installer.replace('@@BUNDLE_BASE64@@', base64).replace('@@BUNDLE_SHA256@@', hash(bundle));
  if (template.scripts.installation.script.includes('@@BUNDLE_')) throw new Error('Unexpanded installer placeholders.');
  await mkdir(destination, { recursive: true });
  const egg = `${JSON.stringify(template, null, 2)}\n`;
  await writeFile(join(destination, 'egg-aarons-support.json'), egg);
  await writeFile(join(destination, 'aarons-support.tar.gz'), bundle);
  await writeFile(join(destination, 'SHA256SUMS'), `${hash(egg)}  egg-aarons-support.json\n${hash(bundle)}  aarons-support.tar.gz\n`);
  console.log(`Built self-contained Pterodactyl egg (${Buffer.byteLength(egg)} bytes) and application bundle in ${relative(root, destination) || '.'}.`);
} finally { await rm(scratch, { recursive: true, force: true }); }
